import React, { useState, useRef, useEffect } from "react";
import styles from "./IrregularImageCropper.module.css"

const IrregularImageCropper= ({ imageSrc }) => {
  const [drawing, setDrawing] = useState(false);
  const [points, setPoints] = useState([]);
  const [imageData, setImageData] = useState(null);
  const [closedPath, setClosedPath] = useState(false);
  const canvasRef = useRef(null);
  const imageRef = useRef(null);
  const draggedPointIndex = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");
    const image = imageRef.current;

    const draw = () => {
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      if (points.length >= 1) {
        context.save();
        context.beginPath();
        context.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          context.lineTo(points[i].x, points[i].y);
        }
        if (closedPath) {
          context.closePath();
          context.clip();
        }
        context.rect(0, 0, canvas.width, canvas.height);
        context.fillStyle = "rgba(0, 0, 0, 0.3)";
        context.fill();
        context.restore();
        context.strokeStyle = "#3399ff"; // Color del borde
        context.lineWidth = 2;
        context.stroke();
        for (let i = 0; i < points.length; i++) {
          context.fillStyle = "#ffffff"; // Color de relleno blanco
          const squareSize = 7; // Tamaño del cuadrado
          context.fillRect(
            points[i].x - squareSize / 2,
            points[i].y - squareSize / 2,
            squareSize,
            squareSize
          );
          context.strokeStyle = "#3399ff"; // Color del borde
          context.strokeRect(
            points[i].x - squareSize / 2,
            points[i].y - squareSize / 2,
            squareSize,
            squareSize
          );
        }
      }
    };

    draw();
  }, [points, closedPath, imageData]);

  const handleMouseDown = (event) => {
    const { offsetX, offsetY } = event.nativeEvent;
    if (closedPath) {
      const clickedPointIndex = points.findIndex((point) => {
        const distance = Math.sqrt(
          (point.x - offsetX) ** 2 + (point.y - offsetY) ** 2
        );
        return distance <= 5; // Radius of 5 pixels for clicking
      });
      if (clickedPointIndex !== -1) {
        draggedPointIndex.current = clickedPointIndex;
        setDrawing(true);
      }
    } else {
      setDrawing(true);
      const clickedPointIndex = points.findIndex((point) => {
        const distance = Math.sqrt(
          (point.x - offsetX) ** 2 + (point.y - offsetY) ** 2
        );
        return distance <= 5; // Radius of 5 pixels for clicking
      });
      if (clickedPointIndex !== -1) {
        draggedPointIndex.current = clickedPointIndex;
      } else {
        setPoints([...points, { x: offsetX, y: offsetY }]);
      }
    }
  };

  const handleMouseUp = () => {
    setDrawing(false);
    draggedPointIndex.current = null;
  };

  const handleMouseMove = (event) => {
    if (drawing && draggedPointIndex.current !== null) {
      const { offsetX, offsetY } = event.nativeEvent;
      const newPoints = [...points];
      newPoints[draggedPointIndex.current] = { x: offsetX, y: offsetY };
      setPoints(newPoints);
    }
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    // Obtener las dimensiones originales de la imagen
    const originalWidth = imageRef.current.width;
    const originalHeight = imageRef.current.height;

    // Encontrar los límites del área recortada
    const minX = Math.min(...points.map((point) => point.x));
    const minY = Math.min(...points.map((point) => point.y));
    const maxX = Math.max(...points.map((point) => point.x));
    const maxY = Math.max(...points.map((point) => point.y));

    // Calcular las dimensiones del canvas recortado
    const croppedWidth = maxX - minX;
    const croppedHeight = maxY - minY;

    // Calcular la relación de escala
    const scaleX = originalWidth / canvas.width;
    const scaleY = originalHeight / canvas.height;

    // Crear un nuevo canvas para contener la imagen recortada con las mismas dimensiones que la región recortada
    const croppedCanvas = document.createElement("canvas");
    const croppedCtx = croppedCanvas.getContext("2d");
    croppedCanvas.width = croppedWidth * scaleX;
    croppedCanvas.height = croppedHeight * scaleY;

    // Recortar el contexto del canvas al área de la máscara de recorte
    croppedCtx.beginPath();
    croppedCtx.moveTo(
      (points[0].x - minX) * scaleX,
      (points[0].y - minY) * scaleY
    );
    for (let i = 1; i < points.length; i++) {
      croppedCtx.lineTo(
        (points[i].x - minX) * scaleX,
        (points[i].y - minY) * scaleY
      );
    }
    croppedCtx.closePath();
    croppedCtx.clip();

    // Dibujar la imagen original en el nuevo canvas recortado
    croppedCtx.drawImage(
      imageRef.current,
      -minX * scaleX,
      -minY * scaleY,
      originalWidth,
      originalHeight
    );

    // Descargar la imagen recortada
    const image = croppedCanvas
      .toDataURL("image/png")
      .replace("image/png", "image/octet-stream");
    const link = document.createElement("a");
    link.download = "cropped_image.png";
    link.href = image;
    link.click();
  };

  const handleUndo = () => {
    if (points.length > 0 && !closedPath) {
      const newPoints = [...points];
      newPoints.pop(); // Remove the last point
      setPoints(newPoints);
    }
  };

  return (
    <div
        className={styles.background}
    
    >
      <div
        className={styles}
      >
        <img
          ref={imageRef}
          src={imageSrc}
          alt="Source"
          style={{ display: "none" }}
          onLoad={() => setImageData(imageRef.current)}
        />
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          style={{ border: "1px solid #000" }}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseMove={handleMouseMove}
        />
        <button onClick={handleDownload}>Download</button>
        <button onClick={handleUndo}>Undo</button>
      </div>
    </div>
  );
};

export default IrregularImageCropper;
